package main

import (
	"encoding/base64"
	"encoding/json"
	"fmt"
	"os"
)

type User struct {
	Username  string   `json:"username"`
	Password  string   `json:"password"`
	FullName  string   `json:"full_name"`
	Emails    []string `json:"emails"`
	Addresses []string `json:"addresses"`
}

func main() {
	user1 := User{
		Username:  "admin",
		Password:  encryptPassword("password"),
		FullName:  "admin",
		Emails:    []string{"admin@gmail.com", "admin2@gmail.com"},
		Addresses: []string{"ABC", "BCD"},
	}
	user2 := User{
		Username:  "admin2",
		Password:  encryptPassword("password2"),
		FullName:  "admin2",
		Emails:    []string{"admin@gmail.com", "admin2@gmail.com"},
		Addresses: []string{"ABC", "BCD"},
	}
	users := []User{user1, user2}
	saveJSON("user.json", users)
}

func saveJSON(fileName string, key interface{}) {
	outFile, err := os.Create(fileName)
	checkError(err)
	defer outFile.Close()
	encoder := json.NewEncoder(outFile)
	err = encoder.Encode(key)
	checkError(err)
}

func checkError(err error) {
	if err != nil {
		fmt.Println("Fatal error ", err.Error())
		os.Exit(1)
	}
}

func encryptPassword(password string) string {
	return base64.StdEncoding.EncodeToString([]byte(password))
}
