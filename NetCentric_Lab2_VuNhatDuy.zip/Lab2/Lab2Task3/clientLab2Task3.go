package main

import (
	"bufio"
	"fmt"
	"net"
	"os"
	"strings"
)

func main() {
	// Connect to the server
	conn, err := net.Dial("tcp", "localhost:8080")
	if err != nil {
		fmt.Println(err)
		return
	}

	defer conn.Close()

	// Read the welcome message from the server
	reader := bufio.NewReader(conn)
	message, _ := reader.ReadString('\n')
	fmt.Print(message)

	// Loop until the game is over
	for {
		// Read the game status from the server
		message, _ := reader.ReadString('\n')
		fmt.Print(message)

		// Check if the game is over
		if strings.Contains(message, "Game over") {
			break
		}

		// Read user input
		fmt.Print("Enter a letter: ")
		text, _ := bufio.NewReader(os.Stdin).ReadString('\n')

		// Send the guess to the server
		conn.Write([]byte(text))
	}
}
